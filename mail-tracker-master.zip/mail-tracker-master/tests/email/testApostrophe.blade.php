<head>
    This is the head
</head>
<body>
<h1>
    This is a test!
</h1>
<p>
    <a class="test" href="http://www.google.com?q=foo'bar">
        Click here
    </a>
</p>
</body>
