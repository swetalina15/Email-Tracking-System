<head>
	This is the head
</head>
<body>
	<h1>
		This is a test!
	</h1>
	<p>
		<img src="{{ $message->embed($imagePath) }}" />
	</p>
</body>
