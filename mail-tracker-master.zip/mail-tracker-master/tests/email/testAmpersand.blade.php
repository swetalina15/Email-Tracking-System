<head>
    This is the head
</head>
<body>
<h1>
    This is a test!
</h1>
<p>
    Please
    <a href="http://www.google.com">Click Here</a>
</p>
<p>
    <a class="test" href="http://www.google.com?q=foo&amp;x=bar">
        Click here, too.
    </a>
</p>
</body>
