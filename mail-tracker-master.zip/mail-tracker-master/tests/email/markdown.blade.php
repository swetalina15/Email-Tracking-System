@component('mail::message')
# This is a test message

THank you for reaing it.
@endcomponent
