{!!$email->content!!}
