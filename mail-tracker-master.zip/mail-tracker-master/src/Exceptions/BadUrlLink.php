<?php

namespace jdavidbakr\MailTracker\Exceptions;

use Exception;

class BadUrlLink extends Exception
{
    //
}
